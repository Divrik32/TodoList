import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Button } from '@mui/material';
import { deleteTodo, toggleTodo } from '../store/todosSlice';
import { Link } from 'react-router-dom';

const TodoTable = () => {
  const todos = useSelector(state => state.todos);
  const dispatch = useDispatch();

  return (
    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      <Button variant="contained" color="primary" component={Link} to="/create" sx={{ margin: 2 }}>
        Add Todo
      </Button>
      <TableContainer>
        <Table stickyHeader>
          <TableHead>
            <TableRow>
              <TableCell>Title</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>End Date</TableCell>
              <TableCell>Image</TableCell>
              <TableCell>Completed</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {todos.map(todo => (
              <TableRow key={todo.id}>
                <TableCell>{todo.title}</TableCell>
                <TableCell>{todo.description}</TableCell>
                <TableCell>{new Date(todo.endDate).toLocaleDateString()}</TableCell>
                <TableCell>
                  <img 
                    src={todo.image || 'https://via.placeholder.com/50'} 
                    alt="Todo" 
                    style={{ width: '50px', height: '50px' }} 
                  />
                </TableCell>
                <TableCell>
                  <Button 
                    variant="outlined" 
                    color={todo.isCompleted ? 'success' : 'warning'} 
                    onClick={() => dispatch(toggleTodo(todo.id))}
                  >
                    {todo.isCompleted ? 'Mark as Incomplete' : 'Mark as Completed'}
                  </Button>
                </TableCell>
                <TableCell>
                  <Button 
                    variant="contained" 
                    color="primary" 
                    component={Link} 
                    to={`/edit/${todo.id}`}
                  >
                    Edit
                  </Button>
                  <Button 
                    variant="contained" 
                    color="secondary" 
                    onClick={() => dispatch(deleteTodo(todo.id))}
                    style={{ marginLeft: '10px' }}
                  >
                    Delete
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
};

export default TodoTable;
